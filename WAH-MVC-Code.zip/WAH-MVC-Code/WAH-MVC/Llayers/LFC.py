import torch
import torch.nn as nn

from hyper.custom import CustomLorentz


class LorentzFullyConnected(nn.Module):
    """
        args:
            manifold: Instance of Lorentz manifold
            in_features, out_features, bias: Same as nn.Linear
            init_scale: Scale parameter for internal normalization
            learn_scale: If scale parameter should be learnable
            normalize: If internal normalization should be applied
    """

    def __init__(
            self,
            manifold: CustomLorentz,
            in_features,
            out_features,
            bias=True,
            init_scale=None,
            learn_scale=False,
            normalize=False
        ):
        super(LorentzFullyConnected, self).__init__()
        self.manifold = manifold
        self.in_features = in_features
        self.out_features = out_features
        self.bias = bias
        self.normalize = normalize

        self.weight = nn.Linear(self.in_features, self.out_features, bias=bias)

        self.init_std = 0.02
        self.reset_parameters()

        # Scale for internal normalization
        if init_scale is not None:
            self.scale = nn.Parameter(torch.ones(()) * init_scale, requires_grad=learn_scale)
        else:
            self.scale = nn.Parameter(torch.ones(()) * 2.3, requires_grad=learn_scale)

    def forward(self, x):
        x = self.weight(x)
        x_time = x[:, 0].unsqueeze(-1)
        x_space = x[:, 1:]

        if self.normalize:
            scale = x_time.sigmoid() * self.scale.exp()
            square_norm = (x_space * x_space).sum(dim=-1, keepdim=True)
            mask = square_norm <= 1e-10
            square_norm[mask] = 1

            unit_length = x_space / torch.sqrt(square_norm)
            x_space = scale * unit_length
            new_x_time = torch.sqrt(scale**2 + 1.0 + 1e-5)
            new_x_time = new_x_time.masked_fill(mask, 1.0)

            mask = mask == False
            x_space = x_space * mask

            x = torch.cat([new_x_time, x_space], dim=-1)
        else:
            x = self.manifold.add_time(x_space)
        return x

    def reset_parameters(self):
        nn.init.uniform_(self.weight.weight, -self.init_std, self.init_std)
        if self.bias:
            nn.init.constant_(self.weight.bias, 0)

# Test case
if __name__ == "__main__":

    manifold = CustomLorentz(-1.0)
    in_features = 1024
    out_features = 256
    layer = LorentzFullyConnected(manifold, in_features, out_features, bias=True, init_scale=1.0, learn_scale=True,
                                  normalize=True)

    input_tensor = torch.randn(64, in_features)  # 假设 batch size 为 32

    output_tensor = layer(input_tensor)

    print(f"输入张量形状: {input_tensor.shape}")
    print(f"输出张量形状: {output_tensor.shape}")