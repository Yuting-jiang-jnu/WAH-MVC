import torch
import torch.nn as nn
import torch.nn.functional as F
from hyper.hyperbolid import Lorentz
import math

from hyper.custom import CustomLorentz

class LorentzMLR(nn.Module):
    def __init__(
            self,
            manifold: CustomLorentz,
            num_features: int,
            num_classes: int
        ):
        super(LorentzMLR, self).__init__()

        self.manifold = manifold


        self.a = torch.nn.Parameter(torch.zeros(num_classes,))
        self.z = torch.nn.Parameter(F.pad(torch.zeros(num_classes, num_features - 2), pad=(1, 0), value=1))

        self.init_weights()
    def forward(self, x):
        sqrt_mK=1.0
        norm_z = torch.norm(self.z, dim=-1)

        w_t = (torch.sinh(sqrt_mK * self.a) * norm_z)
        w_s = torch.cosh(sqrt_mK * self.a.view(-1, 1)) * self.z

        beta = torch.sqrt(-w_t ** 2 + torch.norm(w_s, dim=-1) ** 2)
        alpha = -w_t * x.narrow(-1, 0, 1) + (torch.cosh(sqrt_mK * self.a) * torch.inner(x.narrow(-1, 1, x.shape[-1] - 1), self.z))

        d = 1.0 * torch.abs(torch.asinh(sqrt_mK * alpha / beta))
        logits = torch.sign(alpha) * beta * d
        probs = F.softmax(logits, dim=-1)
        return probs

    def init_weights(self):
        stdv = 1.0 / math.sqrt(self.z.size(1))
        nn.init.uniform_(self.z, -stdv, stdv)
        nn.init.uniform_(self.a, -stdv, stdv)

# Test case
if __name__ == "__main__":
    manifold = CustomLorentz(-1.0)

    num_features = 10
    num_classes = 5

    lorentzmlr = LorentzMLR(manifold=manifold, num_features=num_features, num_classes=num_classes)

    batch_size = 32
    input_data = torch.randn(batch_size, num_features)

    target_labels = torch.randint(0, num_classes, (batch_size,))

    print("输入数据形状:", input_data.shape)
    print("目标标签形状:", target_labels.shape)


    logits = lorentzmlr(input_data)
    print("Logits 形状:", logits.shape)

    criterion = nn.CrossEntropyLoss()
    loss = criterion(logits, target_labels)
    print("交叉熵损失:", loss.item())