import torch
import torch.nn as nn
from torch.nn import Parameter
from hyper.hyperbolid import Lorentz
import numpy as np
from Llayers.LMLR import LorentzMLR
from hyper.custom import CustomLorentz
from Llayers.LFC import LorentzFullyConnected
from Llayers.LBnorm import LorentzBatchNorm
from Llayers.LModules import LorentzReLU

class UnifiedEncoder(nn.Module):
    def __init__(self, input_dim, out_feature_dim, dims, is_image=False, in_channels=None, simple_fc=False):
        super(UnifiedEncoder, self).__init__()
        self.is_image = is_image

        if is_image:
            if in_channels is None:
                raise ValueError("For image data, 'in_channels' must be specified.")
            self.encoder = AlexNet(output_dim=out_feature_dim, in_channels=in_channels, simple_fc=simple_fc)
        else:
            self.encoder = nn.Sequential()
            for i in range(len(dims) + 1):
                if i == 0:
                    self.encoder.add_module('Linear%d' % i, nn.Linear(input_dim, dims[i]))
                elif i == len(dims):
                    self.encoder.add_module('Linear%d' % i, nn.Linear(dims[i - 1], out_feature_dim))
                else:
                    self.encoder.add_module('Linear%d' % i, nn.Linear(dims[i - 1], dims[i]))
                self.encoder.add_module('relu%d' % i, nn.ReLU())

    def forward(self, x):
        if self.is_image:
            return self.encoder(x)
        else:
            return self.encoder(x)

# class UnifiedDecoder(nn.Module):
#     def __init__(self, input_dim, feature_dim, dims, is_image=False):
#         super(UnifiedDecoder, self).__init__()
#         self.is_image = is_image
#
#         if is_image:
#             self.decoder = nn.Sequential(
#                 nn.ConvTranspose2d(64, 32, kernel_size=3, stride=2, padding=1, output_padding=1),
#                 nn.ReLU(inplace=True),
#                 nn.ConvTranspose2d(32, 1, kernel_size=3, stride=2, padding=1, output_padding=1),
#                 nn.Sigmoid()
#             )
#         else:
#             dims = list(reversed(dims))
#             self.decoder = nn.Sequential()
#             for i in range(len(dims) + 1):
#                 if i == 0:
#                     self.decoder.add_module('Linear%d' % i, nn.Linear(feature_dim, dims[i]))
#                 elif i == len(dims):
#                     self.decoder.add_module('Linear%d' % i, nn.Linear(dims[i - 1], input_dim))
#                 else:
#                     self.decoder.add_module('Linear%d' % i, nn.Linear(dims[i - 1], dims[i]))
#                 self.decoder.add_module('relu%d' % i, nn.ReLU())
#
#     def forward(self, x):
#         if self.is_image:
#             return self.decoder(x)
#         else:
#             return self.decoder(x)


class AlexNet(nn.Module):
    def __init__(self, output_dim, in_channels, simple_fc=False):
        super(AlexNet, self).__init__()
        self.features = nn.Sequential(
            nn.Conv2d(in_channels, 32, kernel_size=3, stride=1, padding=1),  # 动态输入通道数
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
        )
        self.avgpool = nn.AdaptiveAvgPool2d((7, 7))

        if simple_fc:
            #[64*7*7 -> 1024 -> output_dim]
            self.fc_layers = nn.Sequential(
                nn.Linear(64 * 7 * 7, 1024),
                nn.ReLU(inplace=True),
                nn.Linear(1024, output_dim)
            )
        else:
            #[64*7*7 -> 1024 -> 512 -> output_dim]
            self.fc_layers = nn.Sequential(
                nn.Linear(64 * 7 * 7, 1024),
                nn.ReLU(inplace=True),
                nn.Linear(1024, 512),
                nn.ReLU(inplace=True),
                nn.Linear(512, output_dim)
            )

    def forward(self, x):
        x = self.features(x)
        x = self.avgpool(x)
        x = x.view(x.shape[0], -1)
        x = self.fc_layers(x)
        return x

class LorentzReducer(nn.Module):
    """
    Implementation of a dimensionality reduction module using Lorentz Fully Connected layers.
    """
    def __init__(self, manifold: CustomLorentz, in_dim, hidden_dim, out_dim):
        super(LorentzReducer, self).__init__()
        self.manifold = manifold

        # Define Lorentz Fully Connected layers for dimensionality reduction

        self.FC1 = nn.Sequential(
            LorentzFullyConnected(
                manifold=manifold,
                in_features=in_dim,
                out_features=hidden_dim,
                bias=True,
                init_scale=None,
                learn_scale=False,
                normalize=True
            ),
            LorentzReLU(manifold)
        )
        self.FC2 = nn.Sequential(
            LorentzFullyConnected(
                manifold=manifold,
                in_features=hidden_dim,
                out_features=out_dim,
                bias=True,
                init_scale=None,
                learn_scale=False,
                normalize=True
            ),
            # LorentzBatchNorm(manifold, hidden_dim),
            LorentzReLU(manifold)
        )
    def forward(self, x):
        x = self.FC1(x)
        x = self.FC2(x)
        return x

class WAHNetwork(nn.Module):
    def __init__(
            self,
            num_views,
            input_sizes,
            dims,
            num_clusters,
            output_dim,
            manifold,
            hide_dim,
            out_dim,
            in_channels,
            is_image,
            simple_fc
    ):
        super(WAHNetwork, self).__init__()
        self.encoders = nn.ModuleList()
        self.manifold=manifold

        for idx in range(num_views):
            is_image = is_image
            in_channels = in_channels
            self.encoders.append(UnifiedEncoder(
                input_dim=input_sizes[idx],
                out_feature_dim=output_dim,
                dims=dims,
                is_image=is_image,
                in_channels=in_channels,
                simple_fc=simple_fc,
            ))

        self.manifold = manifold

        self.reducer = LorentzReducer(
            manifold=manifold,
            in_dim=output_dim + 1,
            hidden_dim=hide_dim,
            out_dim=out_dim
        )
        self.E_to_Lmap = Lorentz.exp
        self.L_to_Emap = Lorentz.log
        self.MLR = LorentzMLR(manifold=manifold, num_features=out_dim, num_classes=num_clusters)

    def forward(self, data_views):
        lbps = []
        features = []

        for idx, data_view in enumerate(data_views):
            high_features = self.encoders[idx](data_view)

            lorentz_manifold =self.manifold #Lorentz(K=-1.0)
            l_feature = Lorentz.euclidean_to_lorentz(high_features, lorentz_manifold)
            lorentz_features = l_feature.to(data_view.device)
            reduced_features = self.reducer(lorentz_features)

            label_probs = self.MLR(reduced_features)

            features.append(reduced_features)
            lbps.append(label_probs)
        return lbps, features
