from torch import nn

class LorentzParameter(nn.Parameter):
    """
    A kind of Variable that is to be considered a module parameter on the space of
    Stiefel manifold. Stiefel manifold is the space of matrices with orthonormal columns.
    """

    def __new__(cls, data=None, requires_grad=True):

        return super(LorentzParameter, cls).__new__(cls, data, requires_grad=requires_grad)

    def __repr__(self):
        return 'Parameter containing:' + self.data.__repr__()


