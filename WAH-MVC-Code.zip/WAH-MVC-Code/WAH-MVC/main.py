import warnings
import os
import numpy as np
import random
import torch
import time
from configs import parser, dataset_configs
from models import *
from layers import *
from loss import *
import geoopt


warnings.filterwarnings("ignore")
args = parser.parse_args(['--db', 'scene'])

print("==========\nArgs:{}\n==========".format(args))

# torch.cuda.set_device(0)
os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu
device = 'cuda' if torch.cuda.is_available() else 'cpu'


def set_seed(seed):
    np.random.seed(seed)
    random.seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.manual_seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


if __name__ == "__main__":
    dataset_config = dataset_configs[args.db]
    args.learning_rate = dataset_config["learning_rate"]
    args.batch_size = dataset_config["batch_size"]
    args.seed = dataset_config["seed"]
    args.con_epochs = dataset_config["con_epochs"]
    args.normalized = dataset_config["normalized"]
    args.temperature_l = dataset_config["temperature_l"]
    lmd = dataset_config["lmd"]
    beta = dataset_config["beta"]
    gamma = dataset_config["gamma"]
    dims = dataset_config["dims"]
    output_dim = dataset_config["output_dim"]
    hide_dim = dataset_config.get("hide_dim", None)
    out_dim = dataset_config.get("out_dim", None)
    in_channels = dataset_config.get("in_channels")
    is_image_list = dataset_config.get("is_image_list")
    simple_fc = dataset_config.get("simple_fc")
    use_direct_cnn = dataset_config.get("use_direct_cnn")
    p = 2  # Fashion,Amazon:p=1
    set_seed(args.seed)
    mv_data = MultiviewData(args.db, device)
    num_views = len(mv_data.data_views)
    num_samples = mv_data.labels.size
    num_clusters = np.unique(mv_data.labels).size
    print(num_clusters)
    input_sizes = np.zeros(num_views, dtype=int)
    manifold = CustomLorentz(K=-1.0)

    for idx in range(num_views):
        input_sizes[idx] = mv_data.data_views[idx].shape[1]
    t = time.time()

    mnw = WAHNetwork(num_views, input_sizes, dims, num_clusters, output_dim,
                      manifold, hide_dim, out_dim, in_channels, is_image_list, simple_fc)
    mnw = mnw.to(device)
    mvc_loss = DeepMVCLoss(args.batch_size, num_clusters)
    optimizer = geoopt.optim.RiemannianAdam(mnw.parameters(), lr=args.learning_rate,
                                            weight_decay=args.weight_decay)

    if args.load_model:
        try:
            state_dict = torch.load('./models/WAH_best_model_%s.pth' % args.db)
            mnw.load_state_dict(state_dict)
            acc, nmi, pur, ari = valid(mnw, mv_data, args.batch_size, num_clusters)
        except FileNotFoundError:
            print(f"Model file for {args.db} not found. Starting training from scratch.")
    else:
        t = time.time()
        fine_tuning_loss_values = np.zeros(args.con_epochs, dtype=np.float64)
        best_acc = 0.0
        print("WAH_train start")

        epoch_times = []

        for epoch in range(args.con_epochs):
            epoch_start = time.time()

            total_loss = contrastive_train(mnw, mv_data, mvc_loss, args.batch_size, lmd, beta, gamma,
                                           args.temperature_l,  args.normalized, epoch, optimizer, p)
            fine_tuning_loss_values[epoch] = total_loss

            epoch_end = time.time()
            epoch_time = epoch_end - epoch_start
            epoch_times.append(epoch_time)

            print(f"Epoch {epoch} took {epoch_time:.2f}s")

            if epoch >= 0 and (epoch % 10 == 0 or epoch == args.con_epochs - 1):
                acc, nmi, pur, ari = valid(mnw, mv_data, args.batch_size, num_clusters)

                if acc > best_acc:
                    best_acc = acc
                    if args.save_model:
                        torch.save(mnw.state_dict(), './models/WAH_best_model_%s.pth' % args.db)

                results_folder = 'all results/train results'
                if not os.path.exists(results_folder):
                    os.makedirs(results_folder)

                file_path = os.path.join(results_folder, f'result_{args.db}.txt')
                with open(file_path, 'a+') as f:
                    f.write(
                        'P:{} \t gamma:{} \t temperature_l:{} \t temperature_p:{} \t {} \t {} \t {} \t lmd:{} \t beta:{} \t acc:{:.6f} \t nmi:{:.6f} \t pur:{:.6f} \t {:.4f} \t {} \t num_view:{} \n'.format(
                            p, gamma, args.temperature_l, args.temperature_p, args.seed, args.batch_size,
                            args.learning_rate, lmd, beta, acc, nmi, pur, (time.time() - t), args.con_epochs,
                            num_views))
                    f.flush()

        print("contrastive_train finished.")
        total_time = time.time() - t
        avg_epoch_time = sum(epoch_times) / len(epoch_times)

        print("Total time elapsed: {:.2f}s".format(total_time))
        print("Average time per epoch: {:.2f}s".format(avg_epoch_time))


        if args.save_model:
            torch.save(mnw.state_dict(), './models/WAH_pytorch_model_%s.pth' % args.db)

        file_path = os.path.join(results_folder, f'result_{args.db}.txt')
        with open(file_path, 'a+') as f:
            f.write(
                "Total training time: {:.2f}s, Average time per epoch: {:.2f}s\n".format(total_time, avg_epoch_time))
            f.flush()