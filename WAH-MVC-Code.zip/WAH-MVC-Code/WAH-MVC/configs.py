# configs.py
import argparse
dataset_configs = {
    "MNIST-USPS": {
        "learning_rate": 0.0001,
        "batch_size": 50,
        "seed": 10,
        "con_epochs": 100,
        "normalized": False,
        "temperature_l": 1,
        "lmd": 0.05,
        "beta": 0.005,
        "gamma": 0.001,
        "dims": None,
        "output_dim": 256,
        "hide_dim": 128,
        "out_dim": 64,
        "in_channels":1,
        "is_image_list":True,
        "simple_fc":False
    },
    "Multi-COIL-10": {
        "learning_rate": 0.0001,
        "batch_size": 50,
        "seed": 20,
        "con_epochs": 100,
        "normalized": False,
        "temperature_l": 1,
        "lmd": 0.1,
        "beta": 0.1,
        "gamma": 0.001,
        "dims": None,
        "output_dim": 256,
        "hide_dim": 128,
        "out_dim": 64,
        "in_channels":1,
        "is_image_list":True,
        "simple_fc":False
    },
    "scene": {
        "learning_rate": 0.0002,
        "batch_size": 100,
        "seed": 50,
        "con_epochs": 100,
        "normalized": True,
        "temperature_l": 0.4,
        "lmd": 0.1,
        "beta": 0.1,
        "gamma": 0.1,
        "dims": None,
        "output_dim": 1024,
        "hide_dim": 512,
        "out_dim": 256,
        "in_channels":1,
        "is_image_list":True,
        "simple_fc":True
    },
    "Fashion": {
        "learning_rate": 0.0002,
        "batch_size": 100,
        "seed": 10,
        "con_epochs": 100,
        "normalized": True,
        "temperature_l": 0.4,
        "lmd": 0.01,
        "beta": 0.005,
        "gamma": 0.001,
        "dims": None,
        "output_dim": 256,
        "hide_dim": 128,
        "out_dim": 64,
        "in_channels":1,
        "is_image_list":True,
        "simple_fc":False
    },
    "Amazon": {
        "learning_rate": 0.0001,
        "batch_size": 100,
        "seed": 10,
        "con_epochs": 100,
        "normalized": True,
        "temperature_l": 0.3,
        "lmd": 0.01,
        "beta": 0.005,
        "gamma": 0.001,
        "dims": [256, 512],
        "output_dim": 256,
        "hide_dim": 128,
        "out_dim": 64,
        "in_channels": 3,
        "is_image_list": True,
        "simple_fc": False
    },
    "Video": {
        "learning_rate": 0.0001,
        "batch_size": 256,
        "seed": 20,
        "con_epochs": 200,
        "normalized": True,
        "temperature_l": 0.9,
        "lmd": 0.5,
        "beta": 0.5,
        "gamma": 0.1,
        "output_dim": 1024,
        "dims": [256, 512],
        "hide_dim": 512,
        "out_dim": 256,
        "in_channels":None,
        "is_image_list":False,
        "simple_fc":False
    }
}


parser = argparse.ArgumentParser(description='WAH-MVC')
parser.add_argument('--load_model', default=False, help='Testing if True or training.')
parser.add_argument('--save_model', default=True, help='Saving the model after training.')
parser.add_argument('--db', type=str, default='Fashion',
                    choices=[ 'MNIST-USPS', 'Multi-COIL-10', 'scene', 'Fashion', 'Amazon','Video'],
                    help='dataset name')
parser.add_argument('--seed', type=int, default=10, help='Initializing random seed.')
parser.add_argument("--con_epochs", default=100, help='Number of epochs to fine-tuning.')
parser.add_argument('-lr', '--learning_rate', type=float, default=0.0005, help='Initializing learning rate.')
parser.add_argument('--weight_decay', type=float, default=0., help='Initializing weight decay.')
parser.add_argument("--temperature_l", type=float, default=0.5)
parser.add_argument("--temperature_p", type=float, default=1.0)
parser.add_argument('--batch_size', default=100, type=int,
                    help='The total number of samples must be evenly divisible by batch_size.')
parser.add_argument('--normalized', type=bool, default=False)
parser.add_argument('--gpu', default='0', type=str, help='GPU device idx.')