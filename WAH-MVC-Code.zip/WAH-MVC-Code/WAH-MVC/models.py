import time

import torch
import torch.nn as nn
import torch.nn.utils as utils
from loss import *
from metrics import *
from dataprocessing import *


def contrastive_train(network_model, mv_data, mvc_loss, batch_size, lmd, beta, gamma, temperature_l,normalized, epoch,
                      optimizer,p):
    network_model.train()
    mv_data_loader, num_views, num_samples, num_clusters = get_multiview_data(mv_data, batch_size)
    total_loss = 0.

    for batch_idx, (sub_data_views, _) in enumerate(mv_data_loader):
        lbps, features= network_model(sub_data_views)
        loss_list = list()

        hhsw_loss = mvc_loss.hhsw_mv_loss_lorentz(features, num_proj=128, p=p, device=features[0].device)
        loss_list.append(gamma * hhsw_loss)

        # ====MLR soft label====
        for i in range(num_views):
            for j in range(i + 1, num_views):
                loss_list.append(lmd * mvc_loss.forward_label(lbps[i], lbps[j], temperature_l, normalized))
                loss_list.append(beta * mvc_loss.forward_prob(lbps[i], lbps[j]))

        loss = sum(loss_list)
        optimizer.zero_grad()
        loss.backward()
        utils.clip_grad_norm_(network_model.parameters(), max_norm=1.0)
        optimizer.step()
        total_loss += loss.item()
    if epoch % 10 == 0:
        print('Contrastive_train, epoch {} loss:{:.7f}'.format(epoch, total_loss / num_samples))

    return total_loss


def inference(network_model, mv_data, batch_size,num_cluster):
    network_model.eval()
    mv_data_loader, num_views, num_samples, _ = get_multiview_data(mv_data, batch_size)

    MLR_pred_vectors = []
    caculate_soft_vector = []
    true_labels_vector = []

    for v in range(num_views):
        MLR_pred_vectors.append([])

    for batch_idx, (sub_data_views, sub_labels) in enumerate(mv_data_loader):
        with torch.no_grad():
            lbps, features= network_model(sub_data_views)
            lbp = sum(lbps) / num_views

        for idx in range(num_views):
            pred_label = torch.argmax(lbps[idx], dim=1)
            MLR_pred_vectors[idx].extend(pred_label.detach().cpu().numpy())

        caculate_soft_vector.extend(lbp.detach().cpu().numpy())
        true_labels_vector.extend(sub_labels)

    total_pred = np.argmax(np.array(caculate_soft_vector), axis=1)
    true_labels_vector = np.array(true_labels_vector).reshape(len(caculate_soft_vector))
    return total_pred, MLR_pred_vectors, true_labels_vector,features


def valid(network_model, mv_data, batch_size,num_cluster):
    total_pred, pred_vectors, labels_vector,features = inference(network_model, mv_data, batch_size,num_cluster)
    num_views = len(mv_data.data_views)

    print("Clustering hhsw results on cluster assignments of each view:")
    for idx in range(num_views):
        acc, nmi, pur, ari = calculate_metrics(labels_vector, pred_vectors[idx])
        print('ACC{} = {:.4f} NMI{} = {:.4f} PUR{} = {:.4f} ARI{}={:.4f}'.format(idx+1, acc, idx+1, nmi, idx+1, pur, idx+1, ari))

    print("Clustering hhsw results on semantic labels: " + str(labels_vector.shape[0]))
    acc, nmi, pur, ari = calculate_metrics(labels_vector, total_pred)
    print('ACC = {:.4f} NMI = {:.4f} PUR = {:.4f} ARI={:.4f}'.format(acc, nmi, pur, ari))
    return acc, nmi, pur, ari
