# Wasserstein-Aligned Hyperbolic Multi-View Clustering

Official code for the AAAI 2026 paper 'Wasserstein-Aligned Hyperbolic Multi-View Clustering'. 
This work was performed by Rui wang, Yuting Jiang, Xiaoqing Luo, Xiao-Jun Wu, Nicu Sebe and Ziheng Chen. Please cite us when making use of our code or ideas.
# Experiment
You may reproduce the experimental results presented in the paper if setting the following parameter "load_model" to True. This means that the program will load the trained model provided by the authors for clustering tasks.
parser.add_argument('--load_model', default=False, help='Testing if True or training.')

# Requirement

--Required Python Packages

python>=3.9.7

pytorch>=1.7.1

numpy>=1.21.5

scikit-learn>=1.0.1

scipy>=1.7.3

geoopt>=0.5.0
